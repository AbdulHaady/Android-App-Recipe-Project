package com.example.recipeproject;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class CreateUserTest {

    @Before
    public void setUp() throws Exception {
        String user= "Admin";

        String password= "123";

        boolean output = false;
        boolean expected = true;


        CreateUser createUser = new CreateUser();
        output = createUser.validatePassword(user,password);


        assertEquals(expected,output);





    }



    @Test
    public void onCreate() {


        String user= "";

        String password= "123";

        boolean output = true;
        boolean expected = true;


        CreateUser createUser = new CreateUser();
        output = createUser.validatePassword(user,password);


        assertEquals(expected,output);


    }


    @After
    public void tearDown() throws Exception {

        String user= "Admin";

        String password= "123";

        boolean output = false;
        boolean expected = true;


        CreateUser createUser = new CreateUser();
        output = createUser.validatePassword(user,password);


        assertEquals(expected,output);

    }
}