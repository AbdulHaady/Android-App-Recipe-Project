package com.example.recipeproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


//database guide is form here https://www.youtube.com/watch?v=9t8VVWebRFM&t=1496s
public class DBrecipe extends SQLiteOpenHelper {
    public DBrecipe(Context context) {
        super(context, "Recipe.db", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        //number of coloums
        db.execSQL("create Table RecipeDetails(recipename TEXT primary key, ingre TEXT, steps TEXT, user TEXT, image TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop Table if exists RecipeDetails");
    }


    //insert data
    public Boolean insertRecipeData(String recipename, String ingre, String steps, String user, String image)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("recipename", recipename);
        contentValues.put("ingre", ingre);
        contentValues.put("steps", steps);
        contentValues.put("user", user);
        contentValues.put("image", image);
        long result = DB.insert("RecipeDetails", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }

    //Update data
    public Boolean updateRecipeData(String recipename, String ingre, String steps, String user, String image)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        // removed recipe name
        contentValues.put("ingre", ingre);
        contentValues.put("steps", steps);
        contentValues.put("user", user);
        contentValues.put("image", image);
        // serch where the data using coursor
        Cursor cursor = DB.rawQuery("Select * from RecipeDetails where recipename = ?", new String[]{recipename});

        if(cursor.getCount()>0) {
            long result = DB.update("RecipeDetails", contentValues, "recipename=?", new String[]{recipename});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }else {
            return false;
        }
    }

    //Delete data
    public Boolean deleteRecipeData(String recipename, String ingre, String steps, String user, String image)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        // removed recipe name
        contentValues.put("ingre", ingre);
        contentValues.put("steps", steps);
        contentValues.put("user", user);
        contentValues.put("image", image);
        // serch where the data using coursor
        Cursor cursor = DB.rawQuery("Select * from RecipeDetails where recipename = ?", new String[]{recipename});

        if(cursor.getCount()>0) {
            long result = DB.delete("RecipeDetails",  "recipename=?", new String[]{recipename});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }else {
            return false;
        }
    }

    //Retrieve data
    public Cursor getData ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();

        // serch where the data using coursor
        Cursor cursor = DB.rawQuery("Select * from RecipeDetails ", null);

        return cursor;
    }
}
