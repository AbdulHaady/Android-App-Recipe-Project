package com.example.recipeproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

public class letsWalk extends AppCompatActivity implements SensorEventListener {
    private TextView textViewStepcounter, textViewStepDetector;
    private SensorManager sensorManager;
    private Sensor mStepCounter;
    private boolean isCounterSensorPresent;
    int stepCount = 0;
    TextView animate_text;
    private Button back_Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lets_walk);

        //add animation reference from xin video
        Animation animation = AnimationUtils.loadAnimation(letsWalk.this,R.anim.bounce);

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        textViewStepcounter = findViewById(R.id.txtStepCounterLW);
        textViewStepDetector = findViewById(R.id.txtStepDetectorLW);
        animate_text = findViewById(R.id.txtdefault);
        back_Button = findViewById(R.id.btnBackLW);


        animate_text.startAnimation(animation);

        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);

        //step counter
        if(sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER) !=null){
            mStepCounter = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);
            isCounterSensorPresent = true;

        }else{
            textViewStepcounter.setText("Counter Sensor is not Present");
            isCounterSensorPresent = false;
        }

        back_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent openDisRecipe = new Intent ( letsWalk.this, MainMenu.class);
                startActivity(openDisRecipe);
            }
        });
    }

    @Override
    public void onSensorChanged(SensorEvent sensorEvent) {
        if(sensorEvent.sensor == mStepCounter){
            stepCount = (int) sensorEvent.values[0];
            textViewStepcounter.setText(String.valueOf(stepCount));
        }

    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i) {

    }

    @Override
    protected void onResume() {
        super.onResume();
        if(sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)!=null){
            sensorManager.registerListener(this, mStepCounter, SensorManager.SENSOR_DELAY_NORMAL);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if(sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)!=null){
            sensorManager.unregisterListener(this, mStepCounter);
        }

    }




}