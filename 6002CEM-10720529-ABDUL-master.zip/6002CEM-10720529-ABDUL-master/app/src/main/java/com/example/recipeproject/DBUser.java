package com.example.recipeproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


//database guide is form here https://www.youtube.com/watch?v=9t8VVWebRFM&t=1496s
public class DBUser extends SQLiteOpenHelper{

    public DBUser(Context context) {
        super(context, "User.db", null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create Table UserDetails(username TEXT primary key, passw TEXT, email TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop Table if exists UserDetails");
    }

    //insert data
    public Boolean insertUserDetails(String username, String passw, String email)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("username", username);
        contentValues.put("passw", passw);
        contentValues.put("email", email);
        long result = DB.insert("UserDetails", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }

    //update data
    public Boolean updateUserDetails(String username, String passw, String email)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        // removed username name
        contentValues.put("passw", passw);
        contentValues.put("email", email);
        // serch where the data using coursor
        Cursor cursor = DB.rawQuery("Select * from UserDetails where username = ?", new String[]{username});

        if(cursor.getCount()>0) {
            long result = DB.update("UserDetails", contentValues, "username=?", new String[]{username});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }else {
            return false;
        }
    }

    //delete data
    public Boolean deleteUserDetails(String username, String passw, String email)
    {
        SQLiteDatabase DB = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        // removed recipe name
        contentValues.put("passw", passw);
        contentValues.put("email", email);
        // serch where the data using coursor
        Cursor cursor = DB.rawQuery("Select * from UserDetails where username = ?", new String[]{username});

        if(cursor.getCount()>0) {
            long result = DB.delete("UserDetails",  "username=?", new String[]{username});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        }else {
            return false;
        }
    }

    //get data
    public Cursor getData ()
    {
        SQLiteDatabase DB = this.getWritableDatabase();

        // serch where the data using coursor
        Cursor cursor = DB.rawQuery("Select * from UserDetails ", null);

        return cursor;
    }

}
