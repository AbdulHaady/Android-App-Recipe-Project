package com.example.recipeproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class DisplayRecipe extends AppCompatActivity {

    private TextView view_recipe_name;
    private TextView view_recipe_ingredience;
    private TextView view_recipe_steps;

    private Button btn_Opn_map;

    public String recipe_name;
    public String recipe_ingredience;
    public String recipe_steps;
    public String recipe_image;

    public ImageView view_image;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_recipe);


        //add animation reference from xin video
        Animation animation = AnimationUtils.loadAnimation(DisplayRecipe.this,R.anim.bounce);


        view_recipe_name = findViewById(R.id.txtRecipeNameDr);
        view_recipe_ingredience = findViewById(R.id.txtIngreDr);
        view_recipe_steps = findViewById(R.id.txtStepsDr);
        btn_Opn_map = findViewById(R.id.btnOpnLocation);

        recipe_name=getIntent().getExtras().getString("recipeName");

        view_image = (ImageView) findViewById(R.id.imgRecipe);

        //create database
        DBrecipe DB;
        DB = new DBrecipe(this);

        Cursor res = DB.getData();
        //read form database
        while(res.moveToNext()){

            if(recipe_name.equals(res.getString(0))){
                recipe_ingredience = res.getString(1);
                recipe_steps = res.getString(2);
                recipe_image = res.getString(4);

            }
        }


        //assign item to database
        view_recipe_name.setText(recipe_name);
        view_recipe_name.startAnimation(animation);
        view_recipe_ingredience.setText(recipe_ingredience);
        view_recipe_steps.setText(recipe_steps);
        //recipe_list.setText(allrecipe);
        // display image
        view_image.setImageBitmap(getBitmapFromEncodedString(recipe_image));



        btn_Opn_map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //btn_Opn_map.startAnimation(animation);
                Intent opnLocationPage = new Intent ( DisplayRecipe.this, MainMenu.class);

                startActivity(opnLocationPage);
            }
        });


    }

    //convert string to Bitmap to display
    private Bitmap getBitmapFromEncodedString(String encodedString){
        byte[] arr = Base64.decode(encodedString, Base64.URL_SAFE);
        Bitmap img = BitmapFactory.decodeByteArray(arr, 0,
                arr.length);
        return img;
    }

}