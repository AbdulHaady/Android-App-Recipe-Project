package com.example.recipeproject;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.opengl.GLDebugHelper;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;

public class AddRecipeMenu extends AppCompatActivity {

    public static final int CAMERA_PERM_CODE = 101;
    public static final int CAMERA_REQUEST_CODE = 102;
    EditText recipename, ingre , steps;
    Button addRecipe;
    public String txtUserName, photo = "";
    Button btn_opn_camera;
    TextView recipe_name_animate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_recipe_menu);
        DBrecipe DB;

        //to get the user form the login main menu
        txtUserName=getIntent().getExtras().getString("username");

        recipename = findViewById(R.id.txtBRcpName);
        ingre = findViewById(R.id.txtBMIngre);
        steps = findViewById(R.id.txtBMSteps);
        addRecipe = findViewById(R.id.btnAddRecipe);
        btn_opn_camera = findViewById(R.id.btnAddImg);
        recipe_name_animate = findViewById(R.id.txtRecipe);

        //load animation reference from xin video
        Animation animation = AnimationUtils.loadAnimation(AddRecipeMenu.this,R.anim.bounce);
        recipe_name_animate.startAnimation(animation);

        //Declare new database
        DB = new DBrecipe(this);

            addRecipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String recipeNameTXT = recipename.getText().toString();
                String indgreTXT = ingre.getText().toString();
                String stepsTXT = steps.getText().toString();

                //Create database create database reference is from  https://www.youtube.com/watch?v=9t8VVWebRFM&t=1496s
                Boolean checkInsertData = DB.insertRecipeData(recipeNameTXT, indgreTXT, stepsTXT, txtUserName, photo);
                if (checkInsertData == true)
                    Toast.makeText(AddRecipeMenu.this, "New Recipe Added", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(AddRecipeMenu.this, "No New Recipe Added", Toast.LENGTH_SHORT).show();

                addRecipe.startAnimation(animation);
            }

        });

            btn_opn_camera.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    askCameraPermision();

                    btn_opn_camera.startAnimation(animation);
                }


            });
    }


    //Request camera permision
    private void askCameraPermision() {
        //ask permission for using camera
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA}, CAMERA_PERM_CODE);
        }else{
            openCamera ();
            //reference for camera code is form here https://www.youtube.com/watch?v=KaDwSvO
        }
    }

    private void openCamera() {
        //open camera
        Intent camera = new Intent (MediaStore.ACTION_IMAGE_CAPTURE);
        startActivityForResult(camera, CAMERA_REQUEST_CODE);
        //reference for camera code is form here https://www.youtube.com/watch?v=KaDwSvO

    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == CAMERA_PERM_CODE){
            if(grantResults.length > 0 && grantResults[0]== PackageManager.PERMISSION_GRANTED){
                //open Camera();
            }else{
                Toast.makeText(this, "Camera Permission is Required to Use camera.", Toast.LENGTH_SHORT).show();
                //reference for camera code is form here https://www.youtube.com/watch?v=KaDwSvO
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_REQUEST_CODE) {
            //retereve bitmap image file
            Bitmap image = (Bitmap) data.getExtras().get("data");
            photo =getEncodedString(image);
            //reference for camera code is form here https://www.youtube.com/watch?v=KaDwSvOpU5E
        }
    }

    //convert bitmap to string
    private String getEncodedString(Bitmap bitmap) {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG,100,os);
        byte[] imagArr = os.toByteArray();
        return Base64.encodeToString(imagArr, Base64.URL_SAFE);
        //reference convert bitmap to string is from xin video
    }
}