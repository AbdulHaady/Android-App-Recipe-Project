package com.example.recipeproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Toast;
import android.widget.TextView;


public class MainMenu extends AppCompatActivity {

    private Button btn_rcpe_list;
    private Button btn_add_rcpe;
    private Button btn_logout;
    private String txt_username;
    private TextView txt_disusername;
    private Button btn_lets_walk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        //add animation reference from xin video
        Animation animation = AnimationUtils.loadAnimation(MainMenu.this,R.anim.bounce);

        btn_rcpe_list = findViewById(R.id.btnRcpeList);
        btn_add_rcpe = findViewById(R.id.btnAddRcpe);
        btn_logout = findViewById(R.id.btnLogOut);
        txt_disusername = findViewById(R.id.txtDisUser);
        btn_lets_walk = findViewById(R.id.btnLetsWalkMM);


        //Retrive username form previous screen
        txt_username=getIntent().getExtras().getString("username");

        txt_disusername.setText("Hi, " + txt_username +"!");

        txt_disusername.startAnimation(animation);




        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainMenu.this, "Goodbye " + txt_username + " !", Toast.LENGTH_SHORT).show();

                Intent opnLogin = new Intent ( MainMenu.this, MainActivity.class);
                startActivity(opnLogin);
            }
        });

        btn_rcpe_list.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent opnRecipe = new Intent ( MainMenu.this, RecipeMenu.class);
                opnRecipe.putExtra("username", txt_username);
                startActivity(opnRecipe);
            }
        });

        btn_add_rcpe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent opnAddRecipe = new Intent ( MainMenu.this, AddRecipeMenu.class);
                opnAddRecipe.putExtra("username", txt_username);
                startActivity(opnAddRecipe);
            }
        });

        btn_lets_walk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent opnLetsWalk = new Intent ( MainMenu.this, letsWalk.class);

                startActivity(opnLetsWalk);

            }
        });

    }
}