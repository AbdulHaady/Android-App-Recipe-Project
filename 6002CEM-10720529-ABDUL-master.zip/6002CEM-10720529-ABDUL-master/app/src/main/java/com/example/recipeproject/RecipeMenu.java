package com.example.recipeproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Objects;

public class RecipeMenu extends AppCompatActivity {

    private Button btn_search_recipe;
    private Button btn_search_camera;
    private EditText txt_search_recipe;
    public String recipe_name;
    private TextView recipe_list, animate_txt;
    private boolean recipe_available;
    private String ayam;


    //test
    private TextView display_username;

    //test
    public String txt_username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_menu);

        //add animation reference from xin video
        Animation animation = AnimationUtils.loadAnimation(RecipeMenu.this,R.anim.bounce);

        //Retrieve username from login
        txt_username=getIntent().getExtras().getString("username");

        animate_txt = findViewById(R.id.txtV1);
        animate_txt.startAnimation(animation);


        btn_search_recipe = findViewById(R.id.btnSerchRcip);
        btn_search_camera = findViewById(R.id.btnSerchRcipCam);
        txt_search_recipe = findViewById(R.id.txtBSerchRcip);
        recipe_list = findViewById(R.id.txtVAllRecipe);

        ayam = "ayam";

        // declare database
        DBrecipe DB;
         DB = new DBrecipe(this);
         String allrecipe= "";

         //serch to find certain database
        Cursor res = DB.getData();
        Cursor res2 = DB.getData();

        //list all recipe available
        while(res.moveToNext()){
            allrecipe = allrecipe + res.getString(0)+ "\n";

        }

        //display recipe in text box
        recipe_list.setText(allrecipe);

        btn_search_recipe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String recipe_loop = "";

                recipe_name = txt_search_recipe.getText().toString();


                //search the data in the while loop
                while(res2.moveToNext()){
                    if(recipe_name.equals(res2.getString(0))){
                        recipe_available = true;
                    }
                }

                if(recipe_available==true){
                    Intent openDisRecipe = new Intent ( RecipeMenu.this, DisplayRecipe.class);
                    openDisRecipe.putExtra("recipeName", recipe_name);
                    startActivity(openDisRecipe);
                }else{
                    Toast.makeText(RecipeMenu.this, "Sorry there is no "+ recipe_name +" recipe!\n" + "thang :"+ recipe_loop , Toast.LENGTH_SHORT).show();
                }


            }
        });



    }
}