package com.example.recipeproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class CreateUser extends AppCompatActivity {

    EditText usernameDb, password1Db, password2Db, emailDb;
    Button create_userDb;
    TextView animate_text;

    boolean isValid = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_user);

        //create database
        DBUser DB;

        //get the user info
        usernameDb = findViewById(R.id.txtBUserNameCU);
        password1Db = findViewById(R.id.txtBpassw1CU);
        password2Db = findViewById(R.id.txtBpassw2CU);
        emailDb = findViewById(R.id.txtBuserEmailCU);
        animate_text = findViewById(R.id.txtMenuCU);

        create_userDb = findViewById(R.id.btnCreateUserCU);

        //add animation reference from xin video
        Animation animation = AnimationUtils.loadAnimation(CreateUser.this,R.anim.bounce);
        animate_text.startAnimation(animation);

        DB = new DBUser(this);

        create_userDb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                create_userDb.startAnimation(animation);

                String  usernameDbTXT= usernameDb.getText().toString();
                String password1DbTXT = password1Db.getText().toString();
                String password2DbTXT = password2Db.getText().toString();
                String emailDbTXT = emailDb.getText().toString();

                //check if database is available
                if(usernameDbTXT.isEmpty() || usernameDbTXT.length() ==0 ||password1DbTXT.isEmpty()|| password1DbTXT.length() == 0||password2DbTXT.isEmpty()|| password2DbTXT.length() == 0||emailDbTXT.isEmpty() || emailDb.length() == 0)
                {
                    Toast.makeText(CreateUser.this, "Please insert value", Toast.LENGTH_SHORT).show();

                }else
                {
                    isValid=validatePassword(password1DbTXT,password2DbTXT);

                    if(!isValid){
                        Toast.makeText(CreateUser.this, "Password is not match", Toast.LENGTH_SHORT).show();
                    }else{

                        Boolean checkInsertData = DB.insertUserDetails(usernameDbTXT, password1DbTXT, emailDbTXT);
                        if (checkInsertData == true)
                            Toast.makeText(CreateUser.this, "New User Created", Toast.LENGTH_SHORT).show();
                        else
                            Toast.makeText(CreateUser.this, "Not able to create user", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });

    }

    // validate password if password 1 is the same as password 2
    public boolean validatePassword(String password1,String password2)
    {
        if(password1.equals(password1) && password2.equals(password2))
        {
            return true;
        }
        return false;
    }
}