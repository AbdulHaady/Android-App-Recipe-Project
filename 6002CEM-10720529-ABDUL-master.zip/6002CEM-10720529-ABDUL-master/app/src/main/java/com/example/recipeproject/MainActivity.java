package com.example.recipeproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText login_password;
    private EditText login_username;
    private Button login_btn;
    private TextView login_info, welcome;
    public String pubUsername;
    private Button create_user_button;

    private String Username = "Admin";
    private String Password = "123";

    boolean isValid = false;
    private int counter = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        login_username = findViewById(R.id.txtBUserName);
        login_password = findViewById(R.id.txtBPassword);
        login_btn = findViewById(R.id.btnLogin);
        login_info = findViewById(R.id.txtTryAttempt);
        welcome = findViewById(R.id.txtWellcome);
        create_user_button = findViewById(R.id.btnNewAcc);


        //add animation reference from xin video
        Animation animation = AnimationUtils.loadAnimation(MainActivity.this,R.anim.bounce);
        welcome.startAnimation(animation);



        //create database based on https://www.youtube.com/watch?v=9t8VVWebRFM&t=1496s
        //create database
        DBUser DB;
        DB = new DBUser(this);

        Cursor userCur = DB.getData();



        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                login_btn.startAnimation(animation);

                String input_username = login_username.getText().toString();
                String input_password = login_password.getText().toString();

                if(input_username.isEmpty() || input_password.isEmpty())
                {
                    Toast.makeText(MainActivity.this, "Wrong username or password!", Toast.LENGTH_SHORT).show();
                }
                else {
                    //validate the username and password
                    isValid = validate(input_username, input_password);

                    if(!isValid){
                        counter--;
                        Toast.makeText(MainActivity.this, "Wrong username or password! Please wait 1 minutes", Toast.LENGTH_SHORT).show();

                        login_info.setText("Tries :" + counter );

                        if(counter == 0){
                            login_btn.setEnabled(false);
                        }
                    }else{
                        Toast.makeText(MainActivity.this, "Welcome " + input_username + " !", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent ( MainActivity.this, MainMenu.class);
                        pubUsername = login_username.getText().toString();
                        intent.putExtra("username", pubUsername);
                        startActivity(intent);
                    }
                }

            }
        });

        create_user_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                create_user_button.startAnimation(animation);
                Intent createUser = new Intent ( MainActivity.this, CreateUser.class);

                startActivity(createUser);
            }
        });

    }


    //validate the password
    private boolean validate(String name, String password)
    {

        DBUser DB;
        DB = new DBUser(this);

        Cursor userCur = DB.getData();

        while(userCur.moveToNext()){

            if(name.equals(userCur.getString(0)) && password.equals(userCur.getString(1))){
                return true;
            }
        }
        return false;

    }

}